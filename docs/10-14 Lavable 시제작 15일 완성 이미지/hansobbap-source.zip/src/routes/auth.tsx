import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "로그인 — 한솥밥" },
      { name: "description", content: "한솥밥에 로그인하고 가족 맞춤 레시피를 받아보세요." },
      { property: "og:title", content: "로그인 — 한솥밥" },
      { property: "og:description", content: "가족 맞춤 레시피 앱 한솥밥 로그인" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: "/kitchen", replace: true });
    });
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "in") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/kitchen", replace: true });
      } else {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin + "/kitchen", data: { display_name: name } },
        });
        if (error) throw error;
        if (data.session) navigate({ to: "/kitchen", replace: true });
        else setSent(true);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      toast.error(msg.includes("Invalid login") ? "이메일 또는 비밀번호가 맞지 않아요." : msg || "문제가 생겼어요.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-warm px-4">
      <div className="paper w-full max-w-sm p-8">
        <h1 className="text-center text-3xl font-bold text-primary">한솥밥</h1>
        <p className="mt-1 text-center font-hand text-2xl text-muted-foreground">온 가족 한 번에 요리</p>
        {sent ? (
          <p className="mt-8 rounded-xl bg-secondary p-4 text-center">
            {email}로 확인 메일을 보냈어요. 메일의 링크를 누르면 가입이 완료돼요.
          </p>
        ) : (
          <form onSubmit={submit} className="mt-8 space-y-4">
            {mode === "up" && (
              <div className="space-y-1.5">
                <Label htmlFor="name">닉네임</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="예: 지우맘" required />
              </div>
            )}
            <div className="space-y-1.5">
              <Label htmlFor="email">이메일</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pw">비밀번호</Label>
              <Input id="pw" type="password" minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} required />
            </div>
            <Button type="submit" className="w-full rounded-full" size="lg" disabled={busy}>
              {mode === "in" ? "로그인" : "가입하기"}
            </Button>
            <button
              type="button"
              className="w-full text-sm text-muted-foreground underline-offset-4 hover:underline"
              onClick={() => setMode(mode === "in" ? "up" : "in")}
            >
              {mode === "in" ? "처음이신가요? 가입하기" : "이미 계정이 있어요"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
