import { createFileRoute, Link } from "@tanstack/react-router";
import { Camera, ShieldAlert, Soup, Share2 } from "lucide-react";
import hero from "@/assets/hero-kitchen.jpg";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "한솥밥 — 알러지·환자식까지 한 번에, 가족 레시피" },
      { name: "description", content: "냉장고·영수증 사진으로 재료를 정리하고, 알러지와 유동식까지 고려한 가족 요리를 한 번의 조리로." },
      { property: "og:title", content: "한솥밥 — 온 가족 한 번에 요리" },
      { property: "og:description", content: "냉장고 재료로 알러지·환자식까지 한 번에 해결하는 가족 레시피 앱" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const features = [
  { icon: Camera, title: "사진 한 장으로 재료 정리", text: "냉장고·영수증 사진에서 신선 재료만 골라내요. 사진은 저장하지 않아요." },
  { icon: ShieldAlert, title: "금지 재료는 빨간색", text: "가족의 알러지 재료를 바로 빨갛게 표시해 실수를 막아요." },
  { icon: Soup, title: "한 냄비, 여러 식단", text: "덜어낼 시점과 유동식·저염식 마무리법까지 한 흐름으로." },
  { icon: Share2, title: "이웃 밥상 공유", text: "완성 사진을 태그와 함께 나누고 좋아요·추천을 받아요." },
];

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <section className="relative overflow-hidden">
        <img src={hero} alt="한 냄비 요리를 가족별 그릇에 나누는 식탁" width={1536} height={1024} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-hero-fade" />
        <div className="relative mx-auto flex min-h-[80vh] max-w-5xl flex-col justify-center px-6 py-20">
          <span className="font-hand text-3xl text-primary">오늘 저녁, 뭐 해먹지?</span>
          <h1 className="mt-2 max-w-lg text-5xl font-bold leading-tight md:text-6xl">
            한 번 요리로
            <br />온 가족이 함께
          </h1>
          <p className="mt-5 max-w-md text-lg text-muted-foreground">
            알러지가 있는 아이도, 유동식을 드시는 어르신도. 같은 냄비에서 시작해 각자에게 맞게 마무리해요.
          </p>
          <div className="mt-8 flex gap-3">
            <Button asChild size="lg" className="rounded-full px-8 shadow-lift">
              <Link to="/kitchen">시작하기</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="rounded-full bg-card/70 px-8">
              <Link to="/auth">로그인</Link>
            </Button>
          </div>
        </div>
      </section>
      <section className="mx-auto grid max-w-5xl gap-5 px-6 py-16 md:grid-cols-2">
        {features.map(({ icon: Icon, title, text }) => (
          <div key={title} className="paper flex gap-4 p-6">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-secondary text-primary">
              <Icon className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold">{title}</h3>
              <p className="mt-1 text-muted-foreground">{text}</p>
            </div>
          </div>
        ))}
      </section>
    </div>
  );
}
