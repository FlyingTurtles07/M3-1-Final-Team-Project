import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Trash2, UserPlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { familyQuery } from "@/lib/family";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/family")({
  head: () => ({
    meta: [
      { title: "우리 가족 — 한솥밥" },
      { name: "description", content: "가족의 알러지와 식사 형태를 등록하세요." },
      { property: "og:title", content: "우리 가족 — 한솥밥" },
      { property: "og:description", content: "알러지·유동식 등 가족 식단 정보" },
    ],
  }),
  component: FamilyPage,
});

const DIETS = ["일반식", "유동식", "연식(부드러운 음식)", "저염식", "당뇨식", "유아식", "채식"];

function FamilyPage() {
  const qc = useQueryClient();
  const { data: members = [] } = useQuery(familyQuery);
  const [name, setName] = useState("");
  const [relation, setRelation] = useState("");
  const [diet, setDiet] = useState("일반식");
  const [allergies, setAllergies] = useState("");
  const [notes, setNotes] = useState("");

  const add = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("family_members").insert({
        name: name.trim(),
        relation: relation.trim() || null,
        diet,
        allergies: allergies.split(/[,，、\s]+/).map((s) => s.trim()).filter(Boolean),
        notes: notes.trim() || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setName(""); setRelation(""); setDiet("일반식"); setAllergies(""); setNotes("");
      qc.invalidateQueries({ queryKey: ["family"] });
      toast.success("가족을 추가했어요");
    },
    onError: () => toast.error("저장하지 못했어요"),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("family_members").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["family"] }),
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">우리 가족</h1>
        <p className="text-muted-foreground">한 번 등록하면 레시피 추천과 재료 표시에 자동으로 반영돼요.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {members.map((m) => (
          <div key={m.id} className="paper relative p-5">
            <button onClick={() => remove.mutate(m.id)} className="absolute right-4 top-4 text-muted-foreground hover:text-destructive" aria-label="삭제">
              <Trash2 className="h-4 w-4" />
            </button>
            <p className="text-xl font-bold">
              {m.name} {m.relation && <span className="text-base font-normal text-muted-foreground">· {m.relation}</span>}
            </p>
            <span className="mt-2 inline-block rounded-full bg-accent px-3 py-0.5 text-sm text-accent-foreground">{m.diet}</span>
            {m.allergies.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {m.allergies.map((a) => (
                  <span key={a} className="rounded-full bg-forbidden-soft px-2.5 py-0.5 text-sm font-medium text-forbidden">
                    {a} 금지
                  </span>
                ))}
              </div>
            )}
            {m.notes && <p className="mt-3 text-sm text-muted-foreground">{m.notes}</p>}
          </div>
        ))}
        {members.length === 0 && (
          <p className="paper p-6 text-muted-foreground md:col-span-2">아직 등록된 가족이 없어요. 아래에서 추가해 주세요.</p>
        )}
      </div>

      <form
        onSubmit={(e) => { e.preventDefault(); if (name.trim()) add.mutate(); }}
        className="paper space-y-4 p-6"
      >
        <h2 className="flex items-center gap-2 text-xl font-bold"><UserPlus className="h-5 w-5 text-primary" />가족 추가</h2>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1.5"><Label>이름</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="예: 지우" required /></div>
          <div className="space-y-1.5"><Label>관계</Label><Input value={relation} onChange={(e) => setRelation(e.target.value)} placeholder="예: 딸, 시어머니" /></div>
        </div>
        <div className="space-y-1.5">
          <Label>식사 형태</Label>
          <div className="flex flex-wrap gap-2">
            {DIETS.map((d) => (
              <button type="button" key={d} onClick={() => setDiet(d)}
                className={`rounded-full border px-3 py-1 text-sm transition ${diet === d ? "border-primary bg-primary text-primary-foreground" : "bg-card hover:bg-secondary"}`}>
                {d}
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-1.5">
          <Label>알러지·금지 재료 (쉼표로 구분)</Label>
          <Input value={allergies} onChange={(e) => setAllergies(e.target.value)} placeholder="예: 땅콩, 새우, 우유" />
        </div>
        <div className="space-y-1.5">
          <Label>메모</Label>
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="예: 삼킴이 어려워 곱게 갈아야 함" />
        </div>
        <Button type="submit" className="rounded-full" disabled={add.isPending}>추가하기</Button>
      </form>
    </div>
  );
}
