import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Heart, ThumbsUp, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/feed")({
  head: () => ({
    meta: [
      { title: "이웃 밥상 — 한솥밥" },
      { name: "description", content: "다른 가정의 요리를 구경하고 좋아요를 남겨요." },
      { property: "og:title", content: "이웃 밥상 — 한솥밥" },
      { property: "og:description", content: "가정 요리 공유 공간" },
    ],
  }),
  component: FeedPage,
});

type Post = {
  id: string;
  user_id: string;
  author_name: string;
  recipe_name: string;
  photo_url: string;
  ingredients: string[];
  note: string | null;
  tags: string[];
  created_at: string;
};

function FeedPage() {
  const qc = useQueryClient();
  const [myId, setMyId] = useState<string | null>(null);

  const postsQ = useQuery({
    queryKey: ["feed"],
    queryFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      setMyId(userData.user?.id ?? null);
      const { data, error } = await supabase.from("posts").select("*").order("created_at", { ascending: false }).limit(50);
      if (error) throw error;
      const posts = data as Post[];
      // Resolve signed URLs for photos
      const paths = posts.map((p) => p.photo_url);
      const signed = new Map<string, string>();
      if (paths.length) {
        const { data: urls } = await supabase.storage.from("dish-photos").createSignedUrls(paths, 3600);
        urls?.forEach((u, i) => { const p = paths[i]; if (p && u.signedUrl) signed.set(p, u.signedUrl); });
      }
      return posts.map((p) => ({ ...p, signedUrl: signed.get(p.photo_url) ?? "" }));
    },
  });

  const reactionsQ = useQuery({
    queryKey: ["feed-reactions"],
    queryFn: async () => {
      const { data, error } = await supabase.from("post_reactions").select("*");
      if (error) throw error;
      return data;
    },
  });

  const react = useMutation({
    mutationFn: async ({ postId, kind, on }: { postId: string; kind: "like" | "cheer"; on: boolean }) => {
      if (on) {
        const { error } = await supabase.from("post_reactions").delete().eq("post_id", postId).eq("kind", kind);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("post_reactions").insert({ post_id: postId, kind });
        if (error) throw error;
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["feed-reactions"] }),
    onError: () => toast.error("반응을 남기지 못했어요"),
  });

  const removePost = useMutation({
    mutationFn: async (post: Post) => {
      const { error } = await supabase.from("posts").delete().eq("id", post.id);
      if (error) throw error;
      await supabase.storage.from("dish-photos").remove([post.photo_url]);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["feed"] });
      toast.success("공유를 삭제했어요");
    },
    onError: () => toast.error("삭제하지 못했어요"),
  });

  const posts = postsQ.data ?? [];
  const reactions = reactionsQ.data ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">이웃 밥상</h1>
        <p className="text-muted-foreground">다른 가정은 오늘 뭘 해먹었을까요?</p>
      </div>

      {postsQ.isLoading && <p className="text-muted-foreground">밥상을 차리는 중이에요…</p>}
      {!postsQ.isLoading && posts.length === 0 && (
        <p className="paper p-6 text-muted-foreground">아직 공유된 요리가 없어요. 레시피를 만들고 첫 번째로 공유해 보세요!</p>
      )}

      <div className="grid gap-5 md:grid-cols-2">
        {posts.map((p) => {
          const mine = p.user_id === myId;
          const myReactions = reactions.filter((r) => r.post_id === p.id);
          const likes = myReactions.filter((r) => r.kind === "like");
          const cheers = myReactions.filter((r) => r.kind === "cheer");
          const iLiked = likes.some((r) => r.user_id === myId);
          const iCheered = cheers.some((r) => r.user_id === myId);
          return (
            <article key={p.id} className="paper overflow-hidden">
              {p.signedUrl && <img src={p.signedUrl} alt={p.recipe_name} className="h-56 w-full object-cover" loading="lazy" />}
              <div className="space-y-3 p-5">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h2 className="text-xl font-bold">{p.recipe_name}</h2>
                    <p className="text-sm text-muted-foreground">{p.author_name} 가정 · {new Date(p.created_at).toLocaleDateString("ko-KR")}</p>
                  </div>
                  {mine && (
                    <button onClick={() => removePost.mutate(p)} aria-label="삭제" className="text-muted-foreground hover:text-forbidden">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {p.ingredients.map((i) => (
                    <span key={i} className="rounded-full bg-secondary px-2.5 py-0.5 text-xs">{i}</span>
                  ))}
                </div>
                {p.note && <p className="text-sm">{p.note}</p>}
                {p.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5">
                    {p.tags.map((t) => (
                      <span key={t} className="rounded-full bg-safe-soft px-2.5 py-0.5 text-xs font-medium text-safe">#{t}</span>
                    ))}
                  </div>
                )}
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => react.mutate({ postId: p.id, kind: "like", on: iLiked })}
                    className={`flex items-center gap-1.5 rounded-full px-4 py-1.5 text-sm transition ${iLiked ? "bg-forbidden-soft font-bold text-forbidden" : "bg-secondary text-muted-foreground"}`}
                  >
                    <Heart className={`h-4 w-4 ${iLiked ? "fill-current" : ""}`} /> 좋아요 {likes.length}
                  </button>
                  <button
                    onClick={() => react.mutate({ postId: p.id, kind: "cheer", on: iCheered })}
                    className={`flex items-center gap-1.5 rounded-full px-4 py-1.5 text-sm transition ${iCheered ? "bg-safe-soft font-bold text-safe" : "bg-secondary text-muted-foreground"}`}
                  >
                    <ThumbsUp className={`h-4 w-4 ${iCheered ? "fill-current" : ""}`} /> 추천 {cheers.length}
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
