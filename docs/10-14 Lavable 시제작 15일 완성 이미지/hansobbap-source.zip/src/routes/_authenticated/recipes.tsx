import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2, Share2 } from "lucide-react";
import { useState } from "react";
import { familyQuery, ingredientsQuery, forbiddenFor, toAiMembers } from "@/lib/family";
import { suggestRecipes, type Recipe } from "@/lib/ai.functions";
import { ShareDialog } from "@/components/ShareDialog";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/recipes")({
  head: () => ({
    meta: [
      { title: "가족 레시피 — 한솥밥" },
      { name: "description", content: "가족 모두를 위한 한 번의 조리 레시피" },
      { property: "og:title", content: "가족 레시피 — 한솥밥" },
      { property: "og:description", content: "알러지·유동식까지 고려한 한 냄비 레시피" },
    ],
  }),
  component: RecipesPage,
});

function RecipesPage() {
  const { data: members = [] } = useQuery(familyQuery);
  const { data: items = [] } = useQuery(ingredientsQuery);
  const suggest = useServerFn(suggestRecipes);
  const [sharing, setSharing] = useState<Recipe | null>(null);
  const mut = useMutation({
    mutationFn: () =>
      suggest({
        data: {
          ingredients: items.map((i) => i.name).filter((n) => !forbiddenFor(n, members)),
          members: toAiMembers(members),
        },
      }),
    onError: (e) => toast.error(e instanceof Error ? e.message : "추천을 받지 못했어요"),
  });

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">가족 레시피</h1>
      <Button size="lg" className="rounded-full" disabled={!items.length || mut.isPending} onClick={() => mut.mutate()}>
        {mut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}재료 {items.length}개로 추천받기
      </Button>
      {mut.data?.map((r) => (
        <div key={r.name} className="paper space-y-3 p-6">
          <h2 className="text-2xl font-bold">{r.name} <span className="text-base text-muted-foreground">· {r.time_minutes}분</span></h2>
          <p className="text-muted-foreground">{r.summary}</p>
          <ol className="list-decimal space-y-1 pl-5">{r.shared_steps.map((s) => <li key={s}>{s}</li>)}</ol>
          {r.member_adaptations.map((m) => (
            <p key={m.member} className="rounded-xl bg-secondary p-3 text-sm"><b>{m.member}</b>: {m.method}</p>
          ))}
          {r.excluded.length > 0 && <p className="text-sm text-forbidden">제외: {r.excluded.join(", ")}</p>}
          <Button variant="outline" className="rounded-full" onClick={() => setSharing(r)}>
            <Share2 className="h-4 w-4" /> 이웃 밥상에 공유
          </Button>
        </div>
      ))}
      {sharing && <ShareDialog recipe={sharing} onClose={() => setSharing(null)} />}
    </div>
  );
}
