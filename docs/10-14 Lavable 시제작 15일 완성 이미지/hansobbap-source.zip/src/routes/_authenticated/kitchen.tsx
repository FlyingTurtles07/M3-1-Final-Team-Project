import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { Camera, Receipt, Plus, X, Loader2, AlertTriangle, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { familyQuery, ingredientsQuery, forbiddenFor, toAiMembers, fileToDataUrl } from "@/lib/family";
import { scanIngredients, type ScannedItem } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/_authenticated/kitchen")({
  head: () => ({
    meta: [
      { title: "우리집 식재료 — 한솥밥" },
      { name: "description", content: "냉장고·영수증 사진이나 직접 입력으로 식재료를 정리하세요." },
      { property: "og:title", content: "우리집 식재료 — 한솥밥" },
      { property: "og:description", content: "사진 한 장으로 식재료 정리, 금지 재료는 빨간색으로" },
    ],
  }),
  component: KitchenPage,
});

type Pending = ScannedItem & { selected: boolean };

function KitchenPage() {
  const qc = useQueryClient();
  const { data: members = [] } = useQuery(familyQuery);
  const { data: items = [] } = useQuery(ingredientsQuery);
  const scan = useServerFn(scanIngredients);
  const fridgeRef = useRef<HTMLInputElement>(null);
  const receiptRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [kind, setKind] = useState<"fridge" | "receipt">("fridge");
  const [pending, setPending] = useState<Pending[]>([]);
  const [manual, setManual] = useState("");

  const scanMut = useMutation({
    mutationFn: async ({ file, k }: { file: File; k: "fridge" | "receipt" }) => {
      const image = await fileToDataUrl(file);
      setPreview(image);
      setKind(k);
      setPending([]);
      return scan({ data: { image, kind: k, members: toAiMembers(members) } });
    },
    onSuccess: (res) => {
      setPending(
        res.map((it) => {
          const local = forbiddenFor(it.name, members);
          const forbidden = it.forbidden || !!local;
          return { ...it, forbidden, reason: it.reason || local || "", selected: true };
        }),
      );
      if (!res.length) toast.info("신선 식재료를 찾지 못했어요");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "사진을 분석하지 못했어요"),
  });

  const save = useMutation({
    mutationFn: async (rows: { name: string; source: string }[]) => {
      const existing = new Set(items.map((i) => i.name));
      const fresh = rows.filter((r) => r.name && !existing.has(r.name));
      if (!fresh.length) return 0;
      const { error } = await supabase.from("ingredients").insert(fresh);
      if (error) throw error;
      return fresh.length;
    },
    onSuccess: (n) => {
      qc.invalidateQueries({ queryKey: ["ingredients"] });
      toast.success(n ? `재료 ${n}개를 저장했어요` : "이미 있는 재료예요");
    },
    onError: () => toast.error("저장하지 못했어요"),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("ingredients").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["ingredients"] }),
  });

  function onFile(k: "fridge" | "receipt") {
    return (e: React.ChangeEvent<HTMLInputElement>) => {
      const f = e.target.files?.[0];
      e.target.value = "";
      if (f) scanMut.mutate({ file: f, k });
    };
  }

  function savePending() {
    const rows = pending.filter((p) => p.selected).map((p) => ({ name: p.name, source: kind }));
    save.mutate(rows, {
      onSuccess: () => { setPending([]); setPreview(null); },
    });
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">우리집 식재료</h1>
        <p className="text-muted-foreground">가공식품과 양념은 빼고, 신선 재료만 모아요. 사진은 저장되지 않아요.</p>
      </div>

      {members.length === 0 && (
        <Link to="/family" className="paper flex items-center gap-3 p-4 text-sm">
          <AlertTriangle className="h-5 w-5 text-primary" />
          가족의 알러지를 먼저 등록하면 금지 재료를 빨간색으로 알려드려요 →
        </Link>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        <input ref={fridgeRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={onFile("fridge")} />
        <input ref={receiptRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={onFile("receipt")} />
        <button onClick={() => fridgeRef.current?.click()} disabled={scanMut.isPending}
          className="paper flex items-center gap-4 p-6 text-left transition hover:shadow-lift">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-primary"><Camera className="h-7 w-7" /></div>
          <div><p className="text-lg font-bold">냉장고 사진</p><p className="text-sm text-muted-foreground">냉장고 속을 찍어 재료를 찾아요</p></div>
        </button>
        <button onClick={() => receiptRef.current?.click()} disabled={scanMut.isPending}
          className="paper flex items-center gap-4 p-6 text-left transition hover:shadow-lift">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary text-primary"><Receipt className="h-7 w-7" /></div>
          <div><p className="text-lg font-bold">영수증 사진</p><p className="text-sm text-muted-foreground">오늘 장 본 영수증을 읽어요</p></div>
        </button>
      </div>

      {preview && (
        <div className="paper grid gap-5 p-5 md:grid-cols-[280px_1fr]">
          <img src={preview} alt="분석 중인 사진" className="max-h-80 w-full rounded-xl object-cover" />
          <div>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-xl font-bold">{kind === "fridge" ? "냉장고에서 찾은 재료" : "영수증에서 찾은 재료"}</h2>
              <button onClick={() => { setPreview(null); setPending([]); }} aria-label="닫기"><X className="h-5 w-5 text-muted-foreground" /></button>
            </div>
            {scanMut.isPending ? (
              <p className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" />사진을 살펴보는 중이에요…</p>
            ) : (
              <>
                <div className="flex flex-wrap gap-2">
                  {pending.map((p, i) => (
                    <button key={p.name + i} title={p.reason}
                      onClick={() => setPending(pending.map((x, j) => (j === i ? { ...x, selected: !x.selected } : x)))}
                      className={`flex items-center gap-1 rounded-full border-2 px-3 py-1 text-sm transition ${
                        p.forbidden ? "border-forbidden bg-forbidden-soft font-bold text-forbidden" : "border-transparent bg-safe-soft text-safe"
                      } ${p.selected ? "" : "opacity-40 line-through"}`}>
                      {p.selected && <Check className="h-3.5 w-3.5" />}
                      {p.name}
                      {p.forbidden && <AlertTriangle className="h-3.5 w-3.5" />}
                    </button>
                  ))}
                </div>
                {pending.some((p) => p.forbidden) && (
                  <ul className="mt-3 space-y-1 text-sm text-forbidden">
                    {pending.filter((p) => p.forbidden).map((p) => <li key={p.name}>⚠ {p.name}: {p.reason}</li>)}
                  </ul>
                )}
                {pending.length > 0 && (
                  <Button className="mt-4 rounded-full" onClick={savePending} disabled={save.isPending}>
                    선택한 재료 저장하기
                  </Button>
                )}
              </>
            )}
          </div>
        </div>
      )}

      <div className="paper p-6">
        <form className="flex gap-2" onSubmit={(e) => {
          e.preventDefault();
          const names = manual.split(/[,，、]+/).map((s) => s.trim()).filter(Boolean);
          if (names.length) save.mutate(names.map((name) => ({ name, source: "manual" })), { onSuccess: () => setManual("") });
        }}>
          <Input value={manual} onChange={(e) => setManual(e.target.value)} placeholder="직접 입력 (예: 애호박, 두부, 표고버섯)" />
          <Button type="submit" className="rounded-full"><Plus className="h-4 w-4" />추가</Button>
        </form>

        <h2 className="mt-6 text-xl font-bold">보관 중인 재료 <span className="text-base font-normal text-muted-foreground">{items.length}개</span></h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {items.map((it) => {
            const bad = forbiddenFor(it.name, members);
            return (
              <span key={it.id} title={bad ?? undefined}
                className={`flex items-center gap-1 rounded-full px-3 py-1 text-sm ${bad ? "bg-forbidden-soft font-bold text-forbidden" : "bg-secondary"}`}>
                {bad && <AlertTriangle className="h-3.5 w-3.5" />}
                {it.name}
                <button onClick={() => remove.mutate(it.id)} aria-label={`${it.name} 삭제`}><X className="h-3.5 w-3.5 opacity-60" /></button>
              </span>
            );
          })}
          {items.length === 0 && <p className="text-muted-foreground">아직 재료가 없어요.</p>}
        </div>
        {items.length > 0 && (
          <Button asChild size="lg" className="mt-6 rounded-full shadow-lift"><Link to="/recipes">이 재료로 레시피 추천받기</Link></Button>
        )}
      </div>
    </div>
  );
}
