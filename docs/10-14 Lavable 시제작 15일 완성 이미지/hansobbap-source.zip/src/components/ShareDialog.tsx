import { useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Camera, Loader2, Share2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { fileToDataUrl } from "@/lib/family";
import type { Recipe } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

async function dataUrlToBlob(dataUrl: string): Promise<Blob> {
  return (await fetch(dataUrl)).blob();
}

export function ShareDialog({ recipe, onClose }: { recipe: Recipe; onClose: () => void }) {
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [photo, setPhoto] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [tags, setTags] = useState("");

  const share = useMutation({
    mutationFn: async () => {
      if (!photo) throw new Error("완성된 요리 사진을 올려주세요");
      const { data: userData } = await supabase.auth.getUser();
      const user = userData.user;
      if (!user) throw new Error("로그인이 필요해요");
      const path = `${user.id}/${crypto.randomUUID()}.jpg`;
      const blob = await dataUrlToBlob(photo);
      const { error: upErr } = await supabase.storage.from("dish-photos").upload(path, blob, { contentType: "image/jpeg" });
      if (upErr) throw upErr;
      const { data: profile } = await supabase.from("profiles").select("display_name").eq("id", user.id).maybeSingle();
      const tagList = tags.split(/[,，#\s]+/).map((t) => t.trim()).filter(Boolean).slice(0, 8);
      const { error } = await supabase.from("posts").insert({
        user_id: user.id,
        author_name: profile?.display_name || "이웃",
        recipe_name: recipe.name,
        photo_url: path,
        ingredients: recipe.uses,
        note: note || null,
        tags: tagList,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["feed"] });
      toast.success("이웃 밥상에 공유했어요!");
      onClose();
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "공유하지 못했어요"),
  });

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/40 p-4 md:items-center" onClick={onClose}>
      <div className="paper w-full max-w-lg space-y-4 p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold">이웃 밥상에 공유하기</h2>
          <button onClick={onClose} aria-label="닫기"><X className="h-5 w-5 text-muted-foreground" /></button>
        </div>

        <input ref={fileRef} type="file" accept="image/*" capture="environment" className="hidden"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (f) setPhoto(await fileToDataUrl(f, 1200));
          }} />
        {photo ? (
          <button onClick={() => fileRef.current?.click()} className="block w-full">
            <img src={photo} alt="완성된 요리" className="max-h-64 w-full rounded-xl object-cover" />
          </button>
        ) : (
          <button onClick={() => fileRef.current?.click()}
            className="flex w-full flex-col items-center gap-2 rounded-xl border-2 border-dashed border-border py-10 text-muted-foreground">
            <Camera className="h-8 w-8" />
            완성된 요리 사진을 찍어주세요
          </button>
        )}

        <div>
          <p className="text-lg font-bold">{recipe.name}</p>
          <div className="mt-1 flex flex-wrap gap-1.5">
            {recipe.uses.map((u) => (
              <span key={u} className="rounded-full bg-secondary px-2.5 py-0.5 text-xs">{u}</span>
            ))}
          </div>
        </div>

        <Textarea value={note} onChange={(e) => setNote(e.target.value)} maxLength={200}
          placeholder="이웃에게 한마디 (예: 아이가 두 그릇 먹었어요!)" />
        <Input value={tags} onChange={(e) => setTags(e.target.value)} maxLength={100}
          placeholder="태그 (예: 유아식, 저염식, 한냄비)" />

        <Button className="w-full rounded-full" size="lg" disabled={share.isPending} onClick={() => share.mutate()}>
          {share.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Share2 className="h-4 w-4" />}
          공유하기
        </Button>
      </div>
    </div>
  );
}
