import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const familyQuery = queryOptions({
  queryKey: ["family"],
  queryFn: async () => {
    const { data, error } = await supabase.from("family_members").select("*").order("created_at");
    if (error) throw error;
    return data;
  },
});

export const ingredientsQuery = queryOptions({
  queryKey: ["ingredients"],
  queryFn: async () => {
    const { data, error } = await supabase.from("ingredients").select("*").order("created_at", { ascending: false });
    if (error) throw error;
    return data;
  },
});

export type FamilyMember = Awaited<ReturnType<NonNullable<typeof familyQuery.queryFn>>>[number];

export function toAiMembers(members: FamilyMember[]) {
  return members.map((m) => ({
    name: m.name,
    relation: m.relation,
    allergies: m.allergies,
    diet: m.diet,
    notes: m.notes,
  }));
}

/** Local safety net: flags a name that matches any family allergy. */
export function forbiddenFor(name: string, members: FamilyMember[]): string | null {
  const n = name.replace(/\s/g, "");
  for (const m of members) {
    for (const a of m.allergies) {
      const k = a.replace(/\s/g, "");
      if (k && (n.includes(k) || k.includes(n))) return `${m.name} - ${a} 알러지`;
    }
  }
  return null;
}

/** Downscale an image file into a JPEG data URL (kept only in memory). */
export async function fileToDataUrl(file: File, max = 1400): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext("2d")!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", 0.85);
}
