// Server-only helper: one streamed Responses call that returns parsed JSON.
const GATEWAY = "https://ai.gateway.lovable.dev/v1/responses";
const MODEL = "openai/gpt-6-astra";

export class AiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export async function callJson<T>(
  instructions: string,
  content: Record<string, unknown>[],
  schemaName: string,
  schema: Record<string, unknown>,
): Promise<T> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new AiError(500, "AI 설정이 아직 준비되지 않았어요.");

  const res = await fetch(GATEWAY, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
      "X-Lovable-AIG-SDK": "fetch",
    },
    body: JSON.stringify({
      model: MODEL,
      instructions,
      input: [{ role: "user", content }],
      stream: true,
      store: false,
      reasoning: { effort: "low" },
      text: { format: { type: "json_schema", name: schemaName, strict: true, schema } },
    }),
  });

  if (!res.ok || !res.body) {
    let msg = "AI 요청에 실패했어요. 잠시 후 다시 시도해 주세요.";
    if (res.status === 429) msg = "요청이 많아요. 잠시 후 다시 시도해 주세요.";
    if (res.status === 402) msg = "AI 사용 크레딧이 부족해요.";
    try {
      const j = (await res.json()) as { message?: string; error?: { message?: string } };
      if (res.status !== 429 && res.status !== 402) msg = j.message ?? j.error?.message ?? msg;
    } catch {
      /* ignore */
    }
    throw new AiError(res.status, msg);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  let text = "";
  let finalText: string | null = null;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const frames = buf.split("\n\n");
    buf = frames.pop() ?? "";
    for (const frame of frames) {
      for (const line of frame.split("\n")) {
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (!data || data === "[DONE]") continue;
        try {
          const ev = JSON.parse(data) as { type?: string; delta?: string; text?: string; response?: { error?: { message?: string } } };
          if (ev.type === "response.output_text.delta" && ev.delta) text += ev.delta;
          else if (ev.type === "response.output_text.done" && typeof ev.text === "string") finalText = ev.text;
          else if (ev.type === "response.failed" || ev.type === "error")
            throw new AiError(500, ev.response?.error?.message ?? "AI 처리 중 오류가 발생했어요.");
        } catch (e) {
          if (e instanceof AiError) throw e;
        }
      }
    }
  }
  const out = finalText ?? text;
  if (!out) throw new AiError(500, "AI가 답변을 만들지 못했어요. 다시 시도해 주세요.");
  return JSON.parse(out) as T;
}
