import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const memberSchema = z.object({
  name: z.string(),
  relation: z.string().nullable().optional(),
  allergies: z.array(z.string()),
  diet: z.string(),
  notes: z.string().nullable().optional(),
});

export type ScannedItem = { name: string; forbidden: boolean; reason: string };
export type Recipe = {
  name: string;
  summary: string;
  time_minutes: number;
  uses: string[];
  excluded: string[];
  shared_steps: string[];
  member_adaptations: { member: string; method: string }[];
  tips: string;
};

function describeFamily(members: z.infer<typeof memberSchema>[]) {
  if (!members.length) return "등록된 가족 구성원 없음 (일반식).";
  return members
    .map(
      (m) =>
        `- ${m.name}${m.relation ? `(${m.relation})` : ""}: 식사형태=${m.diet}; 알러지/금지=${m.allergies.join(", ") || "없음"}${m.notes ? `; 메모=${m.notes}` : ""}`,
    )
    .join("\n");
}

export const scanIngredients = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        image: z.string().startsWith("data:image/").max(8_000_000),
        kind: z.enum(["fridge", "receipt"]),
        members: z.array(memberSchema).max(20),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const { callJson } = await import("./ai.server");
    const instructions = `당신은 한국 가정의 식재료 인식 도우미입니다.
${data.kind === "receipt" ? "영수증 사진에서 구매한 품목을 읽어" : "냉장고 사진에서 보이는 식재료를 찾아"} 신선 식재료만 한국어 일반 명칭으로 나열하세요.
반드시 제외: 가공식품(라면, 과자, 햄, 소시지, 통조림, 음료, 냉동가공식품 등)과 모든 양념/소스/조미료(간장, 된장, 고추장, 소금, 설탕, 식용유, 케첩, 마요네즈 등), 비식품.
가족 정보:
${describeFamily(data.members)}
각 재료가 가족 누군가의 알러지/금지 재료이거나 해당 성분을 포함하면 forbidden=true, reason에 "누구 - 이유"를 짧게. 아니면 forbidden=false, reason="".
중복 없이, 브랜드명 대신 재료명(예: "서울우유 1L" → "우유").`;
    const result = await callJson<{ items: ScannedItem[] }>(
      instructions,
      [
        { type: "input_text", text: "이 사진의 식재료를 JSON으로 정리해 주세요." },
        { type: "input_image", image_url: data.image },
      ],
      "ingredients",
      {
        type: "object",
        additionalProperties: false,
        required: ["items"],
        properties: {
          items: {
            type: "array",
            items: {
              type: "object",
              additionalProperties: false,
              required: ["name", "forbidden", "reason"],
              properties: {
                name: { type: "string" },
                forbidden: { type: "boolean" },
                reason: { type: "string" },
              },
            },
          },
        },
      },
    );
    return result.items;
  });

export const suggestRecipes = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        ingredients: z.array(z.string().max(60)).min(1).max(150),
        members: z.array(memberSchema).max(20),
        request: z.string().max(300).optional(),
      })
      .parse(d),
  )
  .handler(async ({ data }) => {
    const { callJson } = await import("./ai.server");
    const instructions = `당신은 바쁜 주부를 돕는 한국 가정식 요리 연구가입니다.
목표: 가족 모두가 "한 번의 조리 흐름"으로 함께 먹을 수 있는 요리를 3가지 제안.
규칙:
1. 가진 식재료(아래 목록) 위주로 사용. 양념(간장, 소금, 참기름 등 기본 양념)은 있다고 가정해도 됨.
2. 가족 중 누구라도 알러지/금지인 재료는 절대 사용하지 말고 excluded에 그 재료와 이유를 적기.
3. shared_steps: 한 냄비/한 팬에서 공통으로 진행하는 순서. 특정 구성원을 위해 "덜어두는 시점"(예: 간하기 전, 매운 재료 넣기 전)을 단계 안에 명확히 표시.
4. member_adaptations: 유동식, 저염식, 연식, 유아식 등 식사 형태가 다른 구성원별로 덜어낸 뒤 어떻게 마무리하는지(갈기, 묽게 하기, 잘게 썰기 등). 일반식 구성원은 생략 가능.
5. 짧고 실용적으로, 한국어로.
가족 정보:
${describeFamily(data.members)}`;
    const result = await callJson<{ recipes: Recipe[] }>(
      instructions,
      [
        {
          type: "input_text",
          text: `가진 식재료: ${data.ingredients.join(", ")}${data.request ? `\n추가 요청: ${data.request}` : ""}`,
        },
      ],
      "recipes",
      {
        type: "object",
        additionalProperties: false,
        required: ["recipes"],
        properties: {
          recipes: {
            type: "array",
            items: {
              type: "object",
              additionalProperties: false,
              required: ["name", "summary", "time_minutes", "uses", "excluded", "shared_steps", "member_adaptations", "tips"],
              properties: {
                name: { type: "string" },
                summary: { type: "string" },
                time_minutes: { type: "number" },
                uses: { type: "array", items: { type: "string" } },
                excluded: { type: "array", items: { type: "string" } },
                shared_steps: { type: "array", items: { type: "string" } },
                member_adaptations: {
                  type: "array",
                  items: {
                    type: "object",
                    additionalProperties: false,
                    required: ["member", "method"],
                    properties: { member: { type: "string" }, method: { type: "string" } },
                  },
                },
                tips: { type: "string" },
              },
            },
          },
        },
      },
    );
    return result.recipes;
  });
